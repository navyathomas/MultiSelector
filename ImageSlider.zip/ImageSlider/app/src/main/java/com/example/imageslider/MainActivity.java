package com.example.imageslider;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity {

    private ImageSliderAdapter imageSliderAdapter;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageSliderAdapter=new ImageSliderAdapter(this);
        viewPager=findViewById(R.id.view_pager);

        viewPager.setAdapter(imageSliderAdapter);

    }
}
